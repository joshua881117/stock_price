from router import Router

r = Router()

def get_db_router():
    return r
