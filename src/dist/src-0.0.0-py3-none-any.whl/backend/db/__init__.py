from .router import Router

r = router.Router()

def get_db_router():
    return r
